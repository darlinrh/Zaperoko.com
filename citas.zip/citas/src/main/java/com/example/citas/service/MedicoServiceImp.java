package com.example.citas.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.citas.model.Medico;
import com.example.citas.repository.MedicoRepository;

@Service
public class MedicoServiceImp implements MedicoService {

	@Autowired
	private MedicoRepository repositorio;
	
	@Override
	public List<Medico> getMedicos() {
		return repositorio.findAll();
	}

	@Override
	public Optional<Medico> getMedicosId(Long id) {
		return repositorio.findById(id);
	}

	@Override
	public Medico addMedico(Medico medico) {
		return repositorio.save(medico);
	}

}
