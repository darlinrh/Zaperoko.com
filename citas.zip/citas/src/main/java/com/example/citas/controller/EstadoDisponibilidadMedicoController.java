package com.example.citas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.citas.model.EstadoDisponibilidadMedico;
import com.example.citas.service.EstadoDisponibilidadMedicoServiceImp;

@RestController
@RequestMapping("/api/estados_disponibilidad_medico")
public class EstadoDisponibilidadMedicoController {

	@Autowired
	private EstadoDisponibilidadMedicoServiceImp servicio;
	
	@GetMapping
	public ResponseEntity<?> consultarEstado(){
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(servicio.getEstadosDisponibilidadMedico());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> consultarEstadoId(@PathVariable Long id){
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(servicio.getEstadosDisponibilidadMedicoId(id));
	}
	
	@PostMapping
	public ResponseEntity<?> addEstado(@RequestBody EstadoDisponibilidadMedico estado){
		return ResponseEntity.status(HttpStatus.CREATED).body(servicio.crearEstadoDisponibilidadMedico(estado));
	}
}
