package com.example.citas.service;

import java.util.List;
import java.util.Optional;

import com.example.citas.model.Medico;

public interface MedicoService {

	public List<Medico> getMedicos();

	public Optional<Medico> getMedicosId(Long id);

	public Medico addMedico(Medico medico);

}
